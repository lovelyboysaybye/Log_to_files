class LogicClass(object):
    """description of class"""


